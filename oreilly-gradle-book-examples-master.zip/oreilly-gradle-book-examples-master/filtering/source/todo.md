# Today
  * Sharpen [Gradle](http://gradle.org) skills
  * Exercise

# Tomorrow
  * Become a better build master
  * Be awesome

