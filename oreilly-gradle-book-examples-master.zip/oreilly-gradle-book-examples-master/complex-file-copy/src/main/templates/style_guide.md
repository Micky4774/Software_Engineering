# Groovy Template Style Guide

This file describes the visual design style guidelines that should be followed by all templates in this directory. 
