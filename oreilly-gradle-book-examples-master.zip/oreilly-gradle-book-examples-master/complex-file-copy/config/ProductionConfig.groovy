url=jdbc:mysql://internal.hostname/prod_db
username=prod_db_user
password=no_prod_passwords_here
