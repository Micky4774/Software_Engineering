url=jdbc:mysql://localhost/database
username=db_user
password=db_password
