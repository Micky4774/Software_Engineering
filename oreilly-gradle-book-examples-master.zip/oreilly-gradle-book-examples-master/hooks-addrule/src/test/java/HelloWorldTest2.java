import org.junit.Test;
import static org.junit.Assert.*;

public class HelloWorldTest2 {
  @Test
  public void testHelloWorldPrinting2() {
      HelloWorld.main(null);
      assertTrue(true);
  }
}