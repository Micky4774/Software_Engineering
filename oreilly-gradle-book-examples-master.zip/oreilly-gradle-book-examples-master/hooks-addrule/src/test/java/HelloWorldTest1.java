import org.junit.Test;
import static org.junit.Assert.*;

public class HelloWorldTest1 {
  @Test
  public void testHelloWorldPrinting1() {
      HelloWorld.main(null);
      assertTrue(true);
  }
}