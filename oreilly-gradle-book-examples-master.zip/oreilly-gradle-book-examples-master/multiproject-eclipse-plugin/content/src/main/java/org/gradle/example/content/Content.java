package org.gradle.example.content;

import java.util.List;

public interface Content {
  public List<String> getLines();
}
