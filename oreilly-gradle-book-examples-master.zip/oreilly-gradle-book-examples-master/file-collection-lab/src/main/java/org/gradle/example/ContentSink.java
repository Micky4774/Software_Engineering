package org.gradle.example;

public interface ContentSink {

  public void sink(String line);
  
}
