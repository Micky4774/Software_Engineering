package org.gradle.example;

public interface ContentFactory {

    public Content getContentProvider(String poet);

}