import org.apache.log4j.Logger;

public class Main {
    private static Logger logger = Logger.getLogger("com.sample");
    
    public static void main(String args[]) {
        logger.warn("Working along with log4j.");
    }
}
