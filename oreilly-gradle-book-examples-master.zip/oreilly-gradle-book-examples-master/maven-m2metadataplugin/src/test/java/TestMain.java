import org.junit.Test;
import static org.junit.Assert.*;

public class TestMain {
  @Test
  public void testMain() {
      Main.main(null);
  }
}
